# Solution for process_cars.sh
This solution processes car data from cars2.txt and outputs results to output.txt.
## How to Use
1. Ensure your input file is named 'cars2.txt' and formatted correctly.
2. Run the shell script with './process_cars.sh' to generate the output file.
3. Use this Makefile for building and deploying the solution package.
